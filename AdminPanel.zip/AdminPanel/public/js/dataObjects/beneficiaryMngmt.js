const data = [
    {
        id: 'D1534148',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Alex Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '60'
    },
    {
        id: 'D1534154',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Nick',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '40'
    },
    {
        id: 'D1534147',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Giberd',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '50'
    },
    {
        id: 'D1534153',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Rakib Hasan',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '77'
    },
    {
        id: 'D1534151',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Alex Sparrow',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '22'
    },
    {
        id: 'D1534158',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Michael Faradey',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '33'
    },
    {
        id: 'D1534149',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Rofiq Akon',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '23'
    },
    {
        id: 'D1534152',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Hasan Talukder',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '78'
    },
    {
        id: 'D1534146',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '90'
    },
    {
        id: 'D1534145',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '66'
    },
    {
        id: 'D1534143',
        retireeName: 'Rakib Gara',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '11'
    },
    {
        id: 'D1534144',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '77'
    },
    {
        id: 'D1534150',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '33'
    },
    {
        id: 'D1534142',
        retireeName: 'Hasan Talukder',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '56'
    },
    {
        id: 'D1534155',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '23'
    },
    {
        id: 'D1534157',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '67'
    },
    {
        id: 'D1534134',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '32'
    },
    {
        id: 'D1534135',
        retireeName: 'Remos Sergios',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '67'
    },
    {
        id: 'D1534137',
        retireeName: 'Rofiq Remos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '76'
    },
    {
        id: 'D1534156',
        retireeName: 'Sergio Romos',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '34'
    },
    {
        id: 'D1534140',
        retireeName: 'Tanvir Hasan',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '77'
    },
    {
        id: 'D1534138',
        retireeName: 'Mamun Salam',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '54'
    },
    {
        id: 'D1534141',
        retireeName: 'Mary Com',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '56'
    },
    {
        id: 'D1534139',
        retireeName: 'Hari Dash',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '86'
    },
    {
        id: 'D1534136',
        retireeName: 'S.R. Shuvo',
        beneficiaryName: 'Robert Hook',
        relationWithBene: 'son',
        benNum: '+1125 125 1225',
        benPercentage: '43'
    }
]
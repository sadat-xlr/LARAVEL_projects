

<?php $__env->startSection('content'); ?>
  <div class="row align-items-center">
        <div class="col-md-6">
          <table class="table">
            <thead>
              <tr>
               
                <th>Title</th>
                <th>Description</th>
                <th>Author</th>
                <th>Date</th>
                
                
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($news->title); ?></td>
                    <td><?php echo e($news->description); ?></td>
                    <td><?php echo e($news->user->name); ?></td>
                    
                    <td><?php echo e($news->created_at->format('d/m/Y')); ?></td>
                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
            </tbody>
          </table>
        </div>  
        <div class="col-md-4 offset-1">
          <h5>Add Event</h5>
          <form action="<?php echo e(route('store.news')); ?>" method="post">
             <?php echo csrf_field(); ?>
              <div class="form-group ">
                  <label for="exampleInputPassword1">Event Title</label>
                  <input type="text" name="title" class="form-control">
              </div>
              <div class="form-group">
                  <label for="exampleInputEmail1">Description</label>
                  <input type="text" name="description" class="form-control" >
                 
              </div>
                
                <div class="from-group pt-3">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                
            </form>
     
       </div>
   

  </div>
    




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_projects\AdminPanel\resources\views/newses/listNews.blade.php ENDPATH**/ ?>
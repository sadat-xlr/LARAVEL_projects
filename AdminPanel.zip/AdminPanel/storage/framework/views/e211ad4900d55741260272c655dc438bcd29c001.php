
<?php $__env->startSection('content'); ?>
  <div class="row align-items-center">
        <div class="col-md-6">
          <table class="table">
            <thead>
              <tr>
               
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
                
                
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($service->service_title); ?></td>
                    <td><?php echo e($service->service_description); ?></td>
                    <td><?php echo e($service->created_at->format('d/m/Y')); ?></td>
                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
            </tbody>
          </table>
        </div>  
        <div class="col-md-4 offset-1">
          <h5>Add Service</h5>
          <form action="<?php echo e(route('store.service')); ?>" method="post">
             <?php echo csrf_field(); ?>
              <div class="form-group ">
                  <label for="exampleInputPassword1">Description</label>
                  <input type="text" name="service_title" class="form-control">
              </div>
              <div class="form-group">
                  <label for="exampleInputEmail1">Service Name</label>
                  <input type="text" name="service_description" class="form-control" >
                 
              </div>
                
                <div class="from-group pt-3">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                
            </form>
     
       </div>
   

  </div>
    




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_projects\AdminPanel\resources\views/services/listServices.blade.php ENDPATH**/ ?>
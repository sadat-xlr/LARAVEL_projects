

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-6 align-items-center">
    
    <table class="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Name</th>
          <th scope="col">Designation</th>
          <th scope="col">Image</th>
         
          
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <th scope="row"><?php echo e($member->id); ?></th>
              <td><?php echo e($member->name); ?></td>
              <td><?php echo e($member->designation); ?></td>
              <td><img src="/storage/<?php echo e($member->image); ?>" alt="" width="80"></td>
            
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      
      </tbody>
    </table>
  </div>
  <div class="col-md-4 offset-1">
    <h5>Add Member</h5>
    <form action="<?php echo e(route('store.member')); ?>" method="post" enctype="multipart/form-data">
       <?php echo csrf_field(); ?>
        <div class="form-group ">
            <label for="exampleInputPassword1">Event Title</label>
            <input type="text" name="name" class="form-control">
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Description</label>
            <input type="text" name="designation" class="form-control" >
           
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Description</label>
          <input type="file" name="image" class="form-control" >
         
      </div>
          <div class="from-group pt-3">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          
      </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_projects\AdminPanel\resources\views/members/listMember.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(route('store.notice')); ?>" method="post">
        <?php echo csrf_field(); ?>
       <input type="text" name="title">
       <input type="text" name="description">
       <input type="submit">
    
    </form>

</body>
</html><?php /**PATH D:\Laravel_projects\AdminPanel\resources\views/notices/createNotice.blade.php ENDPATH**/ ?>
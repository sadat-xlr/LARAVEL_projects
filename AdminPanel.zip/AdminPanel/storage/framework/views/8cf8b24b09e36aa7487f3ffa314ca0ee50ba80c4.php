
<?php $__env->startSection('content'); ?>
  <div class="statics col-4 align-items-center">
            
  <div>
     <form action="<?php echo e(route('store.service')); ?>" method="post">
        <?php echo csrf_field(); ?>
         <div class="form-group">
             <label for="exampleInputPassword1">Description</label>
             <input type="text" name="service_title" class="form-control">
         </div>
         <div class="form-group">
             <label for="exampleInputEmail1">Service Name</label>
             <input type="text" name="service_description" class="form-control" >
            
         </div>
           
           <div class="from-group pt-3">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
           
       </form>

  </div>
    



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel_projects\AdminPanel\resources\views/services/createServices.blade.php ENDPATH**/ ?>